"use strict";(self.webpackChunk=self.webpackChunk||[]).push([[328],{10328:function(s,p,e){s.exports=e.p+"static/sound_I.1ca573a3.mp3"}}]);
